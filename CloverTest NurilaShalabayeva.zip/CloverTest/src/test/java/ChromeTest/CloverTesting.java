package ChromeTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class CloverTesting {
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver","/Users/nurilashalabayeva/IdeaProjects/CloverTest/src/test/java/utilities/browser/chromedriver");

        WebDriver driver = new ChromeDriver();
        driver.get("http://www.google.com/");
        driver.manage().window().maximize();

        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Clover");
        searchBox.submit();


        List<WebElement> list = driver.findElements(By.xpath("//span[contains(text(),'Clover')]/ancestor::a"));
        list.get(0).click();








    }
}
